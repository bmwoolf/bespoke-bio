#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
command -v uv >/dev/null || python3 -m pip install uv==0.12.24
mkdir -p /workspace/cache
export UV_CACHE_DIR=/tmp/boltzgen-uv-cache
export UV_LINK_MODE=hardlink
# The official template supplies a supported CUDA-enabled Torch. Keep packages on local disk.
uv venv --system-site-packages --python 3.12 /opt/boltzgen-env
curl -fsSL https://codeload.github.com/HannesStark/boltzgen/tar.gz/a07fea1153111ef453aaea7a15697ee05de9291f -o /workspace/boltzgen-source.tar.gz
mkdir -p /workspace/boltzgen-source
tar -xzf /workspace/boltzgen-source.tar.gz -C /workspace/boltzgen-source --strip-components=1
echo 'torch==2.8.0' > constraints.txt
uv pip install --python /opt/boltzgen-env/bin/python /workspace/boltzgen-source --constraint constraints.txt
source /opt/boltzgen-env/bin/activate
python -c 'import torch; assert torch.cuda.is_available(); print(torch.__version__, torch.cuda.get_device_name(0))'
uv pip freeze --python /opt/boltzgen-env/bin/python > worker_requirements.txt
bash run.sh
